from rag.search import index_files, search

index_files([r"C:\Users\DELL\OneDrive\Documents\1 Introduction to Big Data Analytics.docx"])
out = search("What is big data?", top_k=3)
print(out["sources"])
print(out["results"][0]["text"])